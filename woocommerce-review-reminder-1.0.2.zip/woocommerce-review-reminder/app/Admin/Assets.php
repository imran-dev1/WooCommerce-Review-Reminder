<?php
/**
 * Admin asset loading. Assets load only on the plugin's admin pages.
 *
 * @package WooCommerceReviewReminder\Admin
 */

declare( strict_types=1 );

namespace WooCommerceReviewReminder\Admin;

use WooCommerceReviewReminder\Core\Config;

defined( 'ABSPATH' ) || exit;

/**
 * Class Assets
 */
final class Assets {

	/**
	 * Config instance.
	 *
	 * @var Config
	 */
	private Config $config;

	/**
	 * Assets constructor.
	 *
	 * @param Config $config Config instance.
	 */
	public function __construct( Config $config ) {
		$this->config = $config;
	}

	/**
	 * Register enqueue hooks.
	 */
	public function register(): void {
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
	}

	/**
	 * Enqueue the React app on plugin pages only.
	 *
	 * @param string $hook Hook suffix.
	 */
	public function enqueue( string $hook ): void {
		$is_plugin_page = false;
		foreach ( AdminMenu::slugs() as $slug ) {
			if ( strpos( $hook, $slug ) !== false ) {
				$is_plugin_page = true;
				break;
			}
		}

		if ( ! $is_plugin_page ) {
			return;
		}

		// Locate built assets.
		$manifest = WRR_PLUGIN_DIR . 'assets/js/.vite/manifest.json';
		$entry    = null;

		if ( ! file_exists( $manifest ) ) {
			$manifest = WRR_PLUGIN_DIR . 'assets/js/manifest.json';
		}

		if ( file_exists( $manifest ) ) {
			$decoded = json_decode( (string) file_get_contents( $manifest ), true );
			if ( is_array( $decoded ) ) {
				foreach ( $decoded as $chunk ) {
					if ( is_array( $chunk ) && ! empty( $chunk['isEntry'] ) ) {
						$entry = array(
							'js'  => isset( $chunk['file'] ) ? (string) $chunk['file'] : null,
							'css' => isset( $chunk['css'][0] ) ? (string) $chunk['css'][0] : null,
						);
						break;
					}
				}
			}
		}

		// Fallback names used during development.
		if ( ! $entry ) {
			$entry = array(
				'js'  => 'admin.js',
				'css' => 'admin.css',
			);
		}

		if ( ! empty( $entry['css'] ) && file_exists( WRR_PLUGIN_DIR . 'assets/js/' . $entry['css'] ) ) {
			wp_enqueue_style(
				'wrr-admin',
				WRR_PLUGIN_URL . 'assets/js/' . $entry['css'],
				array(),
				WRR_VERSION
			);
		}

		if ( ! empty( $entry['js'] ) && file_exists( WRR_PLUGIN_DIR . 'assets/js/' . $entry['js'] ) ) {
			wp_enqueue_script(
				'wrr-admin',
				WRR_PLUGIN_URL . 'assets/js/' . $entry['js'],
				array(),
				WRR_VERSION,
				true
			);
			wp_localize_script(
				'wrr-admin',
				'WRR_CONFIG',
				$this->config_payload()
			);
		}
	}

	/**
	 * Client-side configuration.
	 *
	 * @return array<string, mixed>
	 */
	private function config_payload(): array {
		return array(
			'restUrl'        => esc_url_raw( rest_url( 'woocommerce-review-reminder/v1/' ) ),
			'nonce'          => wp_create_nonce( 'wp_rest' ),
			'adminUrl'       => esc_url_raw( admin_url( 'admin.php' ) ),
			'pluginUrl'      => esc_url_raw( WRR_PLUGIN_URL ),
			'version'        => WRR_VERSION,
			'wcVersion'      => defined( 'WC_VERSION' ) ? WC_VERSION : '',
			'wpVersion'      => get_bloginfo( 'version' ),
			'siteName'       => get_bloginfo( 'name' ),
			'siteUrl'        => esc_url_raw( home_url( '/' ) ),
			'timezone'       => wp_timezone_string(),
			'onboardingDone' => (bool) get_option( 'wrr_onboarding_complete', false ),
			'hasCampaigns'   => false,
			'userCanManage'  => current_user_can( 'manage_woocommerce' ) || current_user_can( 'manage_options' ),
		);
	}
}
