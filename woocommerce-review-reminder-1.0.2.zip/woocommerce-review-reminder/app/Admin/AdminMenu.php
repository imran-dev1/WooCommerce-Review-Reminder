<?php
/**
 * Admin menu registration.
 *
 * @package WooCommerceReviewReminder\Admin
 */

declare( strict_types=1 );

namespace WooCommerceReviewReminder\Admin;

defined( 'ABSPATH' ) || exit;

/**
 * Class AdminMenu
 */
final class AdminMenu {

	/**
	 * Parent page slug.
	 *
	 * @var string
	 */
	public const SLUG = 'wrr-dashboard';

	/**
	 * Plugin pages (slug suffix => route).
	 *
	 * @var array<string, string>
	 */
	private const PAGES = array(
		'wrr-dashboard' => '/overview',
		'wrr-campaigns' => '/campaigns',
		'wrr-requests'  => '/requests',
		'wrr-reviews'   => '/reviews',
		'wrr-analytics' => '/analytics',
		'wrr-templates' => '/templates',
		'wrr-settings'  => '/settings',
	);

	/**
	 * All plugin page slugs.
	 *
	 * @return string[]
	 */
	public static function slugs(): array {
		return array_keys( self::PAGES );
	}

	/**
	 * Route for a page slug.
	 *
	 * @param string $slug Page slug.
	 * @return string
	 */
	public static function route_for( string $slug ): string {
		return self::PAGES[ $slug ] ?? '/overview';
	}

	/**
	 * Register the admin menu.
	 */
	public function register(): void {
		add_action(
			'admin_menu',
			function (): void {
				add_menu_page(
					__( 'Review Reminder', 'woocommerce-review-reminder' ),
					__( 'Review Reminder', 'woocommerce-review-reminder' ),
					'manage_woocommerce',
					self::SLUG,
					array( $this, 'render_app' ),
					'dashicons-star-filled',
					58
				);

				foreach ( self::PAGES as $slug => $route ) {
					if ( self::SLUG === $slug ) {
						continue;
					}
					add_submenu_page(
						self::SLUG,
						__( 'Review Reminder', 'woocommerce-review-reminder' ),
						$this->menu_label( $route ),
						'manage_woocommerce',
						$slug,
						array( $this, 'render_app' )
					);
				}
			}
		);

		add_action( 'admin_head', array( $this, 'inline_menu_styles' ) );
	}

	/**
	 * Render the React application mount.
	 */
	public function render_app(): void {
		$slug = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : self::SLUG; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Page slug is read-only, sanitized, and safe for routing.
		if ( ! array_key_exists( $slug, self::PAGES ) ) {
			$slug = self::SLUG;
		}
		$route = self::route_for( $slug );

		echo '<div id="wrr-root" data-route="' . esc_attr( $route ) . '" style="min-height:calc(100vh - 50px);"></div>';
	}

	/**
	 * Menu label for a route.
	 *
	 * @param string $route Route.
	 * @return string
	 */
	private function menu_label( string $route ): string {
		$labels = array(
			'/overview'  => __( 'Overview', 'woocommerce-review-reminder' ),
			'/campaigns' => __( 'Campaigns', 'woocommerce-review-reminder' ),
			'/requests'  => __( 'Requests', 'woocommerce-review-reminder' ),
			'/reviews'   => __( 'Reviews', 'woocommerce-review-reminder' ),
			'/analytics' => __( 'Analytics', 'woocommerce-review-reminder' ),
			'/templates' => __( 'Templates', 'woocommerce-review-reminder' ),
			'/settings'  => __( 'Settings', 'woocommerce-review-reminder' ),
		);
		return $labels[ $route ] ?? __( 'Overview', 'woocommerce-review-reminder' );
	}

	/**
	 * Small style tweaks so the WP menu stays tidy.
	 */
	public function inline_menu_styles(): void {
		$screen = get_current_screen();
		if ( ! $screen || false === strpos( (string) $screen->id, 'wrr-' ) ) {
			return;
		}
		echo '<style>#toplevel_page_wrr-dashboard .wp-menu-image img{width:18px;height:18px;}</style>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}
