<?php
/**
 * Admin menu registration and page dispatch.
 *
 * @package WooCommerceReviewReminder\Admin
 */

declare( strict_types=1 );

namespace WooCommerceReviewReminder\Admin;

use WooCommerceReviewReminder\Admin\Views\AnalyticsView;
use WooCommerceReviewReminder\Admin\Views\CampaignEditorView;
use WooCommerceReviewReminder\Admin\Views\CampaignsView;
use WooCommerceReviewReminder\Admin\Views\Icons;
use WooCommerceReviewReminder\Admin\Views\OverviewView;
use WooCommerceReviewReminder\Admin\Views\RequestDetailView;
use WooCommerceReviewReminder\Admin\Views\RequestsView;
use WooCommerceReviewReminder\Admin\Views\ReviewsView;
use WooCommerceReviewReminder\Admin\Views\SettingsView;
use WooCommerceReviewReminder\Admin\Views\TemplatesView;

defined( 'ABSPATH' ) || exit;

/**
 * Class AdminMenu
 */
final class AdminMenu {

	/**
	 * Parent page slug.
	 *
	 * @var string
	 */
	public const SLUG = 'wrr-dashboard';

	/**
	 * Public menu pages (slug => label).
	 *
	 * @var array<string, string>
	 */
	private const PAGES = array(
		AdminPage::DASHBOARD => 'Overview',
		AdminPage::CAMPAIGNS => 'Campaigns',
		AdminPage::REQUESTS  => 'Requests',
		AdminPage::REVIEWS   => 'Reviews',
		AdminPage::ANALYTICS => 'Analytics',
		AdminPage::TEMPLATES => 'Templates',
		AdminPage::SETTINGS  => 'Settings',
	);

	/**
	 * Hidden pages registered so routes resolve.
	 *
	 * @var array<string, string>
	 */
	private const HIDDEN_PAGES = array(
		AdminPage::CAMPAIGN_EDIT  => 'Campaign editor',
		AdminPage::REQUEST_DETAIL => 'Request detail',
	);

	/**
	 * Page slug => renderer callback.
	 *
	 * @var array<string, string>
	 */
	private const RENDERERS = array(
		AdminPage::DASHBOARD      => array( OverviewView::class, 'render' ),
		AdminPage::CAMPAIGNS      => array( CampaignsView::class, 'render' ),
		AdminPage::REQUESTS       => array( RequestsView::class, 'render' ),
		AdminPage::REVIEWS        => array( ReviewsView::class, 'render' ),
		AdminPage::ANALYTICS      => array( AnalyticsView::class, 'render' ),
		AdminPage::TEMPLATES      => array( TemplatesView::class, 'render' ),
		AdminPage::SETTINGS       => array( SettingsView::class, 'render' ),
		AdminPage::CAMPAIGN_EDIT  => array( CampaignEditorView::class, 'render' ),
		AdminPage::REQUEST_DETAIL => array( RequestDetailView::class, 'render' ),
	);

	/**
	 * All plugin page slugs (menu + hidden).
	 *
	 * @return string[]
	 */
	public static function slugs(): array {
		return array_merge( array_keys( self::PAGES ), array_keys( self::HIDDEN_PAGES ) );
	}

	/**
	 * Register the admin menu.
	 */
	public function register(): void {
		add_action(
			'admin_menu',
			function (): void {
				add_menu_page(
					__( 'Review Reminder', 'woocommerce-review-reminder' ),
					__( 'Review Reminder', 'woocommerce-review-reminder' ),
					'manage_woocommerce',
					AdminPage::DASHBOARD,
					array( $this, 'render_app' ),
					'dashicons-star-filled',
					58
				);

				foreach ( self::PAGES as $slug => $label ) {
					if ( AdminPage::DASHBOARD === $slug ) {
						continue;
					}
					add_submenu_page(
						AdminPage::DASHBOARD,
						__( 'Review Reminder', 'woocommerce-review-reminder' ),
						$this->menu_label( $slug ),
						'manage_woocommerce',
						$slug,
						array( $this, 'render_app' )
					);
				}

				foreach ( self::HIDDEN_PAGES as $slug => $label ) {
					add_submenu_page(
						'options.php',
						$this->menu_label( $slug ),
						$this->menu_label( $slug ),
						'manage_woocommerce',
						$slug,
						array( $this, 'render_app' )
					);
				}
			}
		);

		add_action( 'admin_head', array( $this, 'inline_menu_styles' ) );
	}

	/**
	 * Dispatch the current page to its view renderer.
	 */
	public function render_app(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only page slug, sanitized.
		$slug     = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : AdminPage::DASHBOARD;
		$renderer = self::RENDERERS[ $slug ] ?? array( OverviewView::class, 'render' );

		if ( ! is_callable( $renderer ) ) {
			$renderer = array( OverviewView::class, 'render' );
		}

		$this->layout_start( $slug );
		call_user_func( $renderer );
		$this->layout_end();
	}

	/**
	 * Open the app shell (sidebar + main content wrapper).
	 *
	 * @param string $current Current page slug.
	 */
	private function layout_start( string $current ): void {
		echo '<div class="wrr-shell" x-data="wrrShell()">';
		echo '<div class="wrr-sidebar-backdrop" x-show="open" x-on:click="open = false" x-cloak></div>';

		echo '<aside class="wrr-sidebar" x-bind:class="open && \'is-open\'">';

		// Brand.
		echo '<div class="wrr-sidebar-brand">';
		echo '<span class="wrr-sidebar-logo">' . Icons::get( 'star', 'h-5 w-5' ) . '</span>';
		echo '<div class="min-w-0"><div class="wrr-sidebar-title">' . esc_html__( 'Review Reminder', 'woocommerce-review-reminder' ) . '</div>';
		echo '<div class="wrr-sidebar-subtitle">' . esc_html__( 'WooCommerce', 'woocommerce-review-reminder' ) . '</div></div>';
		echo '<button type="button" class="wrr-sidebar-close lg:hidden" x-on:click="open = false" aria-label="' . esc_attr__( 'Close menu', 'woocommerce-review-reminder' ) . '">' . Icons::get( 'x' ) . '</button>';
		echo '</div>';

		// Navigation.
		echo '<nav class="wrr-sidebar-nav">';
		$icons = array(
			AdminPage::DASHBOARD => 'chart',
			AdminPage::CAMPAIGNS => 'megaphone',
			AdminPage::REQUESTS  => 'mail',
			AdminPage::REVIEWS   => 'star',
			AdminPage::ANALYTICS => 'trend',
			AdminPage::TEMPLATES => 'file',
			AdminPage::SETTINGS  => 'settings',
		);
		foreach ( self::PAGES as $slug => $label ) {
			$active = $slug === $current;
			$icon   = $icons[ $slug ] ?? 'inbox';
			echo '<a class="wrr-sidebar-link' . ( $active ? ' is-active' : '' ) . '" href="' . esc_url( admin_url( 'admin.php?page=' . $slug ) ) . '">';
			echo '<span class="wrr-sidebar-icon">' . Icons::get( $icon, 'h-4 w-4' ) . '</span>';
			echo '<span class="wrr-sidebar-text">' . esc_html( $this->menu_label( $slug ) ) . '</span>';
			echo '</a>';
		}
		echo '</nav>';

		// Footer (user).
		$user    = wp_get_current_user();
		$name    = $user->display_name ? (string) $user->display_name : __( 'Admin', 'woocommerce-review-reminder' );
		$initial = function_exists( 'mb_substr' ) ? mb_substr( $name, 0, 1 ) : substr( $name, 0, 1 );
		echo '<div class="wrr-sidebar-footer">';
		echo '<div class="wrr-sidebar-user">';
		echo '<span class="wrr-sidebar-avatar">' . esc_html( strtoupper( $initial ) ) . '</span>';
		echo '<div class="min-w-0"><div class="wrr-sidebar-user-name">' . esc_html( $name ) . '</div>';
		echo '<div class="wrr-sidebar-user-role">' . esc_html__( 'Store manager', 'woocommerce-review-reminder' ) . '</div></div>';
		echo '</div>';
		echo '<a class="wrr-sidebar-logout" href="' . esc_url( wp_logout_url( admin_url() ) ) . '" title="' . esc_attr__( 'Log out', 'woocommerce-review-reminder' ) . '">' . Icons::get( 'logout', 'h-4 w-4' ) . '</a>';
		echo '</div>';

		echo '</aside>';

		// Main content.
		echo '<div class="wrr-main">';
		echo '<div class="wrr-mobile-bar">';
		echo '<button type="button" class="wrr-mobile-menu" x-on:click="open = true" aria-label="' . esc_attr__( 'Open menu', 'woocommerce-review-reminder' ) . '">' . Icons::get( 'menu', 'h-5 w-5' ) . '</button>';
		echo '<span class="wrr-mobile-title">' . esc_html__( 'Review Reminder', 'woocommerce-review-reminder' ) . '</span>';
		echo '</div>';
	}

	/**
	 * Close the app shell.
	 */
	private function layout_end(): void {
		echo '</div>'; // .wrr-main
		echo '</div>'; // .wrr-shell
	}

	/**
	 * Translated menu label for a page slug.
	 *
	 * @param string $slug Page slug.
	 * @return string
	 */
	private function menu_label( string $slug ): string {
		$labels = array(
			AdminPage::DASHBOARD      => __( 'Overview', 'woocommerce-review-reminder' ),
			AdminPage::CAMPAIGNS      => __( 'Campaigns', 'woocommerce-review-reminder' ),
			AdminPage::REQUESTS       => __( 'Requests', 'woocommerce-review-reminder' ),
			AdminPage::REVIEWS        => __( 'Reviews', 'woocommerce-review-reminder' ),
			AdminPage::ANALYTICS      => __( 'Analytics', 'woocommerce-review-reminder' ),
			AdminPage::TEMPLATES      => __( 'Templates', 'woocommerce-review-reminder' ),
			AdminPage::SETTINGS       => __( 'Settings', 'woocommerce-review-reminder' ),
			AdminPage::CAMPAIGN_EDIT  => __( 'Campaign editor', 'woocommerce-review-reminder' ),
			AdminPage::REQUEST_DETAIL => __( 'Request detail', 'woocommerce-review-reminder' ),
		);
		return $labels[ $slug ] ?? __( 'Overview', 'woocommerce-review-reminder' );
	}

	/**
	 * Small style tweaks so the WP menu stays tidy.
	 */
	public function inline_menu_styles(): void {
		$screen = get_current_screen();
		if ( ! $screen || false === strpos( (string) $screen->id, 'wrr-' ) ) {
			return;
		}
		echo '<style>#toplevel_page_wrr-dashboard .wp-menu-image img{width:18px;height:18px;}</style>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}
