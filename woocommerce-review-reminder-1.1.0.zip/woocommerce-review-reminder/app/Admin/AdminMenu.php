<?php
/**
 * Admin menu registration and page dispatch.
 *
 * @package WooCommerceReviewReminder\Admin
 */

declare( strict_types=1 );

namespace WooCommerceReviewReminder\Admin;

use WooCommerceReviewReminder\Admin\Views\AnalyticsView;
use WooCommerceReviewReminder\Admin\Views\CampaignEditorView;
use WooCommerceReviewReminder\Admin\Views\CampaignsView;
use WooCommerceReviewReminder\Admin\Views\OverviewView;
use WooCommerceReviewReminder\Admin\Views\RequestDetailView;
use WooCommerceReviewReminder\Admin\Views\RequestsView;
use WooCommerceReviewReminder\Admin\Views\ReviewsView;
use WooCommerceReviewReminder\Admin\Views\SettingsView;
use WooCommerceReviewReminder\Admin\Views\TemplatesView;

defined( 'ABSPATH' ) || exit;

/**
 * Class AdminMenu
 */
final class AdminMenu {

	/**
	 * Parent page slug.
	 *
	 * @var string
	 */
	public const SLUG = 'wrr-dashboard';

	/**
	 * Public menu pages (slug => label).
	 *
	 * @var array<string, string>
	 */
	private const PAGES = array(
		AdminPage::DASHBOARD => 'Overview',
		AdminPage::CAMPAIGNS => 'Campaigns',
		AdminPage::REQUESTS  => 'Requests',
		AdminPage::REVIEWS   => 'Reviews',
		AdminPage::ANALYTICS => 'Analytics',
		AdminPage::TEMPLATES => 'Templates',
		AdminPage::SETTINGS  => 'Settings',
	);

	/**
	 * Hidden pages registered so routes resolve.
	 *
	 * @var array<string, string>
	 */
	private const HIDDEN_PAGES = array(
		AdminPage::CAMPAIGN_EDIT  => 'Campaign editor',
		AdminPage::REQUEST_DETAIL => 'Request detail',
	);

	/**
	 * Page slug => renderer callback.
	 *
	 * @var array<string, string>
	 */
	private const RENDERERS = array(
		AdminPage::DASHBOARD      => array( OverviewView::class, 'render' ),
		AdminPage::CAMPAIGNS      => array( CampaignsView::class, 'render' ),
		AdminPage::REQUESTS       => array( RequestsView::class, 'render' ),
		AdminPage::REVIEWS        => array( ReviewsView::class, 'render' ),
		AdminPage::ANALYTICS      => array( AnalyticsView::class, 'render' ),
		AdminPage::TEMPLATES      => array( TemplatesView::class, 'render' ),
		AdminPage::SETTINGS       => array( SettingsView::class, 'render' ),
		AdminPage::CAMPAIGN_EDIT  => array( CampaignEditorView::class, 'render' ),
		AdminPage::REQUEST_DETAIL => array( RequestDetailView::class, 'render' ),
	);

	/**
	 * All plugin page slugs (menu + hidden).
	 *
	 * @return string[]
	 */
	public static function slugs(): array {
		return array_merge( array_keys( self::PAGES ), array_keys( self::HIDDEN_PAGES ) );
	}

	/**
	 * Register the admin menu.
	 */
	public function register(): void {
		add_action(
			'admin_menu',
			function (): void {
				add_menu_page(
					__( 'Review Reminder', 'woocommerce-review-reminder' ),
					__( 'Review Reminder', 'woocommerce-review-reminder' ),
					'manage_woocommerce',
					AdminPage::DASHBOARD,
					array( $this, 'render_app' ),
					'dashicons-star-filled',
					58
				);

				foreach ( self::PAGES as $slug => $label ) {
					if ( AdminPage::DASHBOARD === $slug ) {
						continue;
					}
					add_submenu_page(
						AdminPage::DASHBOARD,
						__( 'Review Reminder', 'woocommerce-review-reminder' ),
						$this->menu_label( $slug ),
						'manage_woocommerce',
						$slug,
						array( $this, 'render_app' )
					);
				}

				foreach ( self::HIDDEN_PAGES as $slug => $label ) {
					add_submenu_page(
						'options.php',
						$this->menu_label( $slug ),
						$this->menu_label( $slug ),
						'manage_woocommerce',
						$slug,
						array( $this, 'render_app' )
					);
				}
			}
		);

		add_action( 'admin_head', array( $this, 'inline_menu_styles' ) );
	}

	/**
	 * Dispatch the current page to its view renderer.
	 */
	public function render_app(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only page slug, sanitized.
		$slug     = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : AdminPage::DASHBOARD;
		$renderer = self::RENDERERS[ $slug ] ?? array( OverviewView::class, 'render' );

		if ( ! is_callable( $renderer ) ) {
			$renderer = array( OverviewView::class, 'render' );
		}

		call_user_func( $renderer );
	}

	/**
	 * Translated menu label for a page slug.
	 *
	 * @param string $slug Page slug.
	 * @return string
	 */
	private function menu_label( string $slug ): string {
		$labels = array(
			AdminPage::DASHBOARD      => __( 'Overview', 'woocommerce-review-reminder' ),
			AdminPage::CAMPAIGNS      => __( 'Campaigns', 'woocommerce-review-reminder' ),
			AdminPage::REQUESTS       => __( 'Requests', 'woocommerce-review-reminder' ),
			AdminPage::REVIEWS        => __( 'Reviews', 'woocommerce-review-reminder' ),
			AdminPage::ANALYTICS      => __( 'Analytics', 'woocommerce-review-reminder' ),
			AdminPage::TEMPLATES      => __( 'Templates', 'woocommerce-review-reminder' ),
			AdminPage::SETTINGS       => __( 'Settings', 'woocommerce-review-reminder' ),
			AdminPage::CAMPAIGN_EDIT  => __( 'Campaign editor', 'woocommerce-review-reminder' ),
			AdminPage::REQUEST_DETAIL => __( 'Request detail', 'woocommerce-review-reminder' ),
		);
		return $labels[ $slug ] ?? __( 'Overview', 'woocommerce-review-reminder' );
	}

	/**
	 * Small style tweaks so the WP menu stays tidy.
	 */
	public function inline_menu_styles(): void {
		$screen = get_current_screen();
		if ( ! $screen || false === strpos( (string) $screen->id, 'wrr-' ) ) {
			return;
		}
		echo '<style>#toplevel_page_wrr-dashboard .wp-menu-image img{width:18px;height:18px;}</style>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}
